To set a packaging type as required:

#. Go to *Sales > Configuration > Products > Product Packaging Type*.
#. You can make a type required
