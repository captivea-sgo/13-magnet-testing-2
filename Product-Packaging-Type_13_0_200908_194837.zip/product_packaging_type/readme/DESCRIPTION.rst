This module allows odoo users to declare packaging types
