* Syvain Van Hoof (Okia sprl) <sylvainvh@okia.be>
* Jacques-Etienne Baudoux (BCIM) <je@bcim.be>
* Guewen Baconnier (Camptocamp) <guewen.baconnier@camptocamp.com>
* Akim Juillerat <akim.juillerat@camptocamp.com>
